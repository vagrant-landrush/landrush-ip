module LandrushIp
  module Cap
    module Linux
      def self.binary_path
        '/usr/local/bin/landrush-ip'
      end
    end
  end
end
