module LandrushIp
  module Cap
    module Windows
      def self.binary_path
        'C:\\landrush-ip.exe'
      end
    end
  end
end
