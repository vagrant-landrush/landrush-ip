module LandrushIp
  VERSION = '0.2.6'.freeze
end
